@extends('layouts.front')

@section('content')
<section class="login-signup">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-6">
 
        <div class="tab-content" id="nav-tabContent">
          <div class="tab-pane fade show active" id="nav-log" role="tabpanel" aria-labelledby="nav-log-tab">
            <div class="login-area">
              <div class="header-area">
                <h4 class="title">Thanks for Registration.You can login after admin approval</h4>
              </div>
             
            </div>
          </div>
         
        </div>

      </div>

    </div>
  </div>
</section>
@endsection